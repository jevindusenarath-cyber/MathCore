const grid = document.querySelector("#game-grid");
const search = document.querySelector("#search");
const count = document.querySelector("#game-count");
const dialog = document.querySelector("#game-dialog");
const frame = document.querySelector("#game-frame");
const dialogTitle = document.querySelector("#dialog-title");

let games = [];

function renderGames(query = "") {
  const term = query.trim().toLowerCase();
  const filtered = games.filter((game) =>
    `${game.title} ${game.description} ${game.category}`.toLowerCase().includes(term)
  );

  count.textContent = `${filtered.length} GAME${filtered.length === 1 ? "" : "S"}`;

  if (!filtered.length) {
    grid.innerHTML = '<p class="empty-state">No games found. Try another search.</p>';
    return;
  }

  grid.innerHTML = filtered.map((game) => `
    <article class="game-card">
      <div class="card-art" aria-hidden="true">${game.emoji}</div>
      <div class="card-info">
        <h3>${escapeHTML(game.title)}</h3>
        <p>${escapeHTML(game.description)}</p>
        <div class="card-bottom">
          <span class="tag">${escapeHTML(game.category)}</span>
          <button class="play-button" type="button" data-game-id="${escapeHTML(game.id)}">
            Play <span aria-hidden="true">→</span>
          </button>
        </div>
      </div>
    </article>
  `).join("");
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

grid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-game-id]");
  if (!button) return;

  const game = games.find((item) => item.id === button.dataset.gameId);
  if (!game) return;

  dialogTitle.textContent = game.title;
  frame.title = game.title;
  frame.src = game.iframe;
  dialog.showModal();
});

function closeGame() {
  dialog.close();
  frame.src = "about:blank";
}

document.querySelector("#close-game").addEventListener("click", closeGame);
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) closeGame();
});
search.addEventListener("input", () => renderGames(search.value));

fetch("games.json")
  .then((response) => {
    if (!response.ok) throw new Error(`Could not load games.json (${response.status})`);
    return response.json();
  })
  .then((data) => {
    games = data.games;
    renderGames();
  })
  .catch((error) => {
    grid.innerHTML = `<p class="empty-state">${escapeHTML(error.message)}. Start a local web server and reload.</p>`;
  });